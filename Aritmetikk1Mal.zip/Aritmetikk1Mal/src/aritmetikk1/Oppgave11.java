package aritmetikk1;

import static javax.swing.JOptionPane.showInputDialog;

public class Oppgave11 {
    /*
    Les inn et tall mellom 0 og 1000 og skriv ut summen av sifrene i tallet (tverrsummen). 
    F.eks inndata 751 skal gi utdata 7 + 5 + 1 = 13. Tips: 751 % 10 = 1 og 751 / 10 = 75.
    */
    public static void main(String[] args) {
       
    }
}
