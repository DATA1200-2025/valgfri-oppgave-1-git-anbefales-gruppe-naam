package aritmetikk1;

public class Oppgave8 {
    /*
    Hva blir resultatet av 
    double tall1=1;
    double tall2=2;
    double resultat;
    resultat = tall1 * 4 + (tall2 * 2 + tall1 ) / (tall2-tall1*3);
    System.out.println(resultat);
    */
    public static void main(String[] args) {
        
    }
}
