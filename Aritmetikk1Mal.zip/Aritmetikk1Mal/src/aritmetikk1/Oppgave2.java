package aritmetikk1;

public class Oppgave2 {
    /*
    Lag et program som definerer en variabel int antall=0. 
    Skriv så ut partallene mellom 0 og 10 (2,4,6,8) ved å øke variabelen med 2 mellom hver gang.
    */
    public static void main(String[] args) {
        
    }
}
