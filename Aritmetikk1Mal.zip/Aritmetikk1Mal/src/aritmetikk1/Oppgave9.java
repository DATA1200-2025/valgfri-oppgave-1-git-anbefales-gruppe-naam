package aritmetikk1;

public class Oppgave9 {
    /*
    sett tall1 = 5
    sett tall2 = 4
    tall1 == tall2 : ?
    tall1 != tall2 : ?
    tall1 <= tall2 : ?
    tall1 >= tall2 : ?
    tall1 < tall2  : ?
    tall1 > tall2  : ?
    */
    public static void main(String[] args) {
       
    }
}
