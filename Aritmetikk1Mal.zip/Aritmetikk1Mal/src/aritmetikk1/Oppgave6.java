package aritmetikk1;

import static javax.swing.JOptionPane.showInputDialog;

public class Oppgave6 {
    /*
    Lag et program som leser inn et beløp i amerikanske dollar (USD) og 
    regner om og skriver ut tilsvarende beløp i norske kroner.
    Benytt dagens valutakurs fra nettet.
    */
    
    public static void main(String[] args) {
       
    }
}
