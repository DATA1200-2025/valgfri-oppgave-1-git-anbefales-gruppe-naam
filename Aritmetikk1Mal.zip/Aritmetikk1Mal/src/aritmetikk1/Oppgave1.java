package aritmetikk1;

import static javax.swing.JOptionPane.*;

public class Oppgave1 {
    /*
    Les inn to variabler; navn, alder. Skriv så følgende historie (et eksempel): 
    Per Olsen er i dag 32 år. Han er født i 1986. I 2053 er han 67 år og da vil han være pensjonist.
    */
    public static void main(String[] args) {
        
    }
}
