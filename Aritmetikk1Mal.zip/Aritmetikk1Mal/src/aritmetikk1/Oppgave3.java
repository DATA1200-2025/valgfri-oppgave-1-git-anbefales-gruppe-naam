package aritmetikk1;

import static javax.swing.JOptionPane.*;

public class Oppgave3 {
    /*
    Lag et program som regner ut arealet av et rektangel. 
    Programmet skal lese inn lengden og bredden på rektangelet.  
    Regn så ut arealet og skriver ut svaret på følgende måte:
    ”Et rektangel med bredde 20 cm og lengde 40 cm har et areal på 800 cm”.
    */
    public static void main(String[] args) {
       
    }
}
