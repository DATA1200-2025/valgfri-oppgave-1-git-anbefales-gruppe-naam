package variabler2;

import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;

public class Oppgave4 {
    /*
    Endre på programmet i oppgave 3 slik at du sikrer at det skrives inn tall 
    og ikke vanlig tekst i input-boksene. 
    Bruk try og catch for å få dette til. Dersom det ikke skrives inn tall sett input til 0.
    */
    public static void main(String[] args) {
        
    }
}
