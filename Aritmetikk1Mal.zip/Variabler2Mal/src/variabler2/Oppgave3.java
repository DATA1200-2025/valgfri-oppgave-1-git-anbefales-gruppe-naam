package variabler2;

import static javax.swing.JOptionPane.*;

public class Oppgave3 {
    /*
    Utvid programmet i oppgave 2 og beregn gjennomsnittet av tallene som er lest inn. 
    Vis så dette resultatet via 1) Meldingsboks og 2) System.out.
    */
    public static void main(String[] args) {
        
    }
}
