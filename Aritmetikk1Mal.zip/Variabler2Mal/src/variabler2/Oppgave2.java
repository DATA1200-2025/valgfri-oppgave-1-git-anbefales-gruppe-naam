package variabler2;

import static javax.swing.JOptionPane.*;

public class Oppgave2 {
    /*
    Lag et program som leser inn tre desimaltall. 
    Programmet skal så summere disse tallene og vise summen i System.out.
    */
    public static void main(String[] args) {
        
    }
}
