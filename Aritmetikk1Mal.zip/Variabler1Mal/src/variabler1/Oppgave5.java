package variabler1;

import static javax.swing.JOptionPane.showInputDialog;

public class Oppgave5 {
    /*
    Endre oppgave 4 slik at utskriften ikke kommer i en meldingsboks, men i System.out.
    */
    public static void main(String[] args) {
        
    }
}
