package variabler1;

import static javax.swing.JOptionPane.*;

public class Oppgave2 {
    /*
    Utvid oppgave 2 med å lese inn alderen.  
    Programmet skal så vise følgende i meldingsboksen:  ”Alderen til Ole Olsen er 21 år.”
    */
    public static void main(String[] args) {
        
    }
}
