package variabler1;

import static javax.swing.JOptionPane.*;

public class Oppgave1 {
    /*
    Lag et program som leser inn en persons fornavn og etternavn hver for seg 
    (altså i to forskjellige input-bokser), skjøter dem sammen, 
    og skriver det fullstendige navnet ut igjen som del av en passende tekst i en meldingsboks. 
    Bruk passende ledetekster ved innlesing, slik at brukeren forstår hva som skal skrives inn. 
    Kjør også dette programmet gjentatte ganger, slik at du ser at utskriften varierer 
    med hva du skriver inn.
    */
    public static void main(String[] args) {
        
    }
}
