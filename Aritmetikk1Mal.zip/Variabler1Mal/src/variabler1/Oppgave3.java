package variabler1;

import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;

public class Oppgave3 {
    /*
    Utvid oppgave 2 med adresse, poststed og postnr. 
    Les inn dataene i flere inputbox'er og skriv det ut i en setning 
    f.eks : Ole Olsen bor i Osloveien 23 som har postnummer 0470 i Oslo. Ole’s alder er 21 år.
    */
    public static void main(String[] args) {
        
    }
}
