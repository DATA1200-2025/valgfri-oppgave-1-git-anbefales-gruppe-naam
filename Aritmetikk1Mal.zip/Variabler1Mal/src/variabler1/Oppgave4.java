package variabler1;

import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;

public class Oppgave4 {
    /*
    Endre oppgave 3 slik at det vises følgende i meldingsboksen:
    Navn : Ole Olsen
    Adresse : Osloveien 23
    Postnummer : 0470
    Poststed : Oslo
    Alder : 21 år.
    Tips: bruk \n for å få ny linje
    */
    public static void main(String[] args) {
        
    }
}
